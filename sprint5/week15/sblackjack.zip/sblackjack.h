#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>

#define TESTING false

// Card values
#define NO_CARD         0       // Missing card from hand or deck 
#define ACE_SPADES      0x01    //49
#define KING_SPADES     0x0D    //61
#define ACE_DIAMONDS    0x11    //33
#define KING_DIAMONDS   0x1D    //45
#define ACE_CLUBS       0x21    //17
#define KING_CLUBS      0x2D    //29
#define ACE_HEARTS      0x31    //1
#define KING_HEARTS     0x3D    //13

// Card ranks
#define RANK_KING       'K'
#define RANK_QUEEN      'Q'
#define RANK_JACK       'J'
#define RANK_TEN        'T'
#define RANK_NINE       '9'
#define RANK_EIGHT      '8'
#define RANK_SEVEN      '7'
#define RANK_SIX        '6'
#define RANK_FIVE       '5'
#define RANK_FOUR       '4'
#define RANK_THREE      '3'
#define RANK_TWO        '2'
#define RANK_ACE        'A'
#define RANK_NO_CARD    ' '     //Rank char for missing card is blank space

// Card suits
#define SUIT_SPADES     'S'
#define SUIT_DIAMONDS   'D'
#define SUIT_CLUBS      'C'
#define SUIT_HEARTS     'H'
#define SUIT_NO_CARD    ' '     //Suit char for missing card is blank space

#define DECK_SIZE 52
#define HAND_SIZE 3
#define BUSTED -1               // Hands with a value over 21 are 'busted'

//deck
void make_deck(int deck[DECK_SIZE]);
void shuffle(int deck[DECK_SIZE]);
int deal_card(int deck[DECK_SIZE]);
void fan_deck(int deck[DECK_SIZE]);
//hand
int get_hand_value(int hand[HAND_SIZE]);
bool hand_has_ace(int hand[HAND_SIZE]);
//cards
char get_card_suit(int card);
char get_card_rank(int card);
void show_card(int card);
int get_card_face_value(int card);
