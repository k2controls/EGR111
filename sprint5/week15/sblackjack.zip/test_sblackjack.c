#include "sblackjack.h"

#if TESTING
#include "acutest.h"

void can_make_deck()
{
    // Function creates a card deck using four
    // for loops - one for each suit. The card
    // order must match that specified on this
    // site: https://ambitiouswithcards.com/new-deck-order/
    // No joker cards are included.
    int my_deck[DECK_SIZE];
    make_deck(my_deck);
    TEST_CHECK(my_deck[0] == ACE_SPADES);
    TEST_CHECK(my_deck[12] == KING_SPADES);
    TEST_CHECK(my_deck[13] == ACE_DIAMONDS);
    TEST_CHECK(my_deck[25] == KING_DIAMONDS);
    TEST_CHECK(my_deck[26] == KING_CLUBS);
    TEST_CHECK(my_deck[38] == ACE_CLUBS);
    TEST_CHECK(my_deck[39] == KING_HEARTS);
    TEST_CHECK(my_deck[51] == ACE_HEARTS);
}

void can_check_new_deck_is_not_shuffled()
{
    // Test by checking first three cards in each suit.
    // Cards should be sequential in new deck.
    // Clubs and hearts are in descending order. 
    int my_deck[DECK_SIZE];
    make_deck(my_deck);

    int suit_offset = 0;    //check spade sequence
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+1]-1);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+2]-2);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+3]-3);
    suit_offset = 13;       //check diamond sequence
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+1]-1);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+2]-2);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+3]-3);
    suit_offset = 26;       //check club sequence
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+1]+1);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+2]+2);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+3]+3);
    suit_offset = 39;       //check heart sequence
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+1]+1);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+2]+2);
    TEST_CHECK(my_deck[suit_offset]==my_deck[suit_offset+3]+3);
    
}

void can_check_deck_is_shuffled()
{
    // Test by checking first three cards in each suit.
    // Cards should NOT be sequential in shuffled deck. 
    int my_deck[DECK_SIZE];
    make_deck(my_deck);
    shuffle(my_deck);     //review swap() and rand() functions from prior coding.
    
    int suit_offset = 0;    //check spade sequence
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+1]-1);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+2]-2);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+3]-3);
    suit_offset = 13;       //check diamond sequence
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+1]-1);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+2]-2);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+3]-3);
    suit_offset = 26;       //check club sequence
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+1]+1);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+2]+2);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+3]+3);
    suit_offset = 39;       //check heart sequence
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+1]+1);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+2]+2);
    TEST_CHECK(my_deck[suit_offset]!=my_deck[suit_offset+3]+3);
}    

void can_deal_card()
{
    // deal_card() returns the value of the next card
    // in the deck. Dealt card location in the deck is 
    // replaced with a NO_CARD (zero) value. So next card 
    // is always the first non-zero value.
    int my_deck[DECK_SIZE];
    make_deck(my_deck);
    shuffle(my_deck);
    int card0 = my_deck[0];
    int card1 = my_deck[1];
    int draw_card0 = deal_card(my_deck);
    int draw_card1 = deal_card(my_deck);
    TEST_CHECK(card0 == draw_card0);
    TEST_CHECK(card1 == draw_card1);
    TEST_CHECK(my_deck[0] == NO_CARD);    //dealt card position contains NO_CARD 0 value.
    TEST_CHECK(my_deck[1] == NO_CARD);    //dealt card position contains NO_CARD 0 value.
    //next card in deck
    TEST_CHECK(my_deck[2] != NO_CARD);    //next card position is not zero.
}

void can_show_card()
{
    // show_card is not testable.
    // Displays first two cards.
    // Displays NO_CARD spaces. 
    // Displays last card in deck.
    int my_deck[DECK_SIZE];
    make_deck(my_deck);
    show_card(my_deck[0]);
    printf(" ");
    show_card(my_deck[1]);
    printf(" ");
    show_card(NO_CARD);
    printf(" ");
    show_card(my_deck[DECK_SIZE-1]);
    printf("\n");
    TEST_CHECK(true);       //not testable. Always returns pass. 'AS 2S    AH' displayed.
}

void can_fan_new_deck()
{
    // fan_deck is not testable. Displays the new
    // deck in the test terminal.
    int my_deck[DECK_SIZE];
    make_deck(my_deck);
    fan_deck(my_deck);  // Check terminal window for display
    TEST_CHECK(true);   // Not testable. Always returns pass.
}

void can_fan_shuffled_deck()
{
    // fan_deck is not testable. Displays shuffled
    // deck in the test terminal.
    int my_deck[DECK_SIZE];
    make_deck(my_deck);
    shuffle(my_deck);   
    fan_deck(my_deck);  // Check terminal window for display
    TEST_CHECK(true);   // Not testable. Always returns pass.
}

void can_get_card_rank()
{
    // Hint: Remove suit. Use switch structure to convert
    // int value to char rank. Other solutions are valid too! 
    int card1 = ACE_DIAMONDS;   // Ace
    int card2 = ACE_HEARTS+5;   // 6
    int card3 = KING_SPADES-3;  // 10
    int card4 = KING_HEARTS-1;  // Queen
    int card5 = KING_CLUBS;     // King
    int card6 = NO_CARD;        // Empty or missing card from hand or deck
    char value1 = get_card_rank(card1);
    char value2 = get_card_rank(card2);
    char value3 = get_card_rank(card3);
    char value4 = get_card_rank(card4);
    char value5 = get_card_rank(card5);
    char value6 = get_card_rank(card6);
    TEST_CHECK(value1==RANK_ACE);
    TEST_CHECK(value2==RANK_SIX);
    TEST_CHECK(value3==RANK_TEN);
    TEST_CHECK(value4==RANK_QUEEN);
    TEST_CHECK(value5==RANK_KING);
    TEST_CHECK(value6==RANK_NO_CARD);
}

void can_get_card_suit()
{
    int card1 = ACE_DIAMONDS;
    int card2 = ACE_HEARTS+5;
    int card3 = KING_SPADES-3;
    int card4 = KING_HEARTS-1; 
    int card5 = KING_CLUBS;
    int card6 = NO_CARD;        // Empty or missing card from hand or deck 
    char value1 = get_card_suit(card1);
    char value2 = get_card_suit(card2);
    char value3 = get_card_suit(card3);
    char value4 = get_card_suit(card4);
    char value5 = get_card_suit(card5);
    char value6 = get_card_suit(card6);
    TEST_CHECK(value1=SUIT_DIAMONDS);
    TEST_CHECK(value2==SUIT_HEARTS);
    TEST_CHECK(value3==SUIT_SPADES);
    TEST_CHECK(value4==SUIT_HEARTS);
    TEST_CHECK(value5==SUIT_CLUBS);
    TEST_CHECK(value6==SUIT_NO_CARD);
}

void can_get_card_face_value()
{
    // int get_card_face_value(int card);
    int card1 = ACE_DIAMONDS;
    int card2 = ACE_HEARTS+5;
    int card3 = KING_SPADES-3;
    int card4 = KING_HEARTS-1; 
    int card5 = KING_CLUBS;
    int card6 = NO_CARD;
    int value1 = get_card_face_value(card1);
    int value2 = get_card_face_value(card2);
    int value3 = get_card_face_value(card3);
    int value4 = get_card_face_value(card4);
    int value5 = get_card_face_value(card5);
    int value6 = get_card_face_value(card6);
    TEST_CHECK(value1==11);
    TEST_CHECK(value2==6);
    TEST_CHECK(value3==10);
    TEST_CHECK(value4==10);
    TEST_CHECK(value5==10);
    TEST_CHECK(value6==0);      // Empty or missing card from hand or deck have zero value.
}

void can_get_hand_value()
{
    // Face cards are worth 10 and Aces are 11 unless
    // hand is over 21. Then Ace can be 1. Hands with a 
    // value over 21 must return BUSTED (-1).
    int TWO_OF_SPADES = ACE_SPADES+1;
    int SIX_OF_HEARTS = ACE_HEARTS+5;
    int JACK_OF_CLUBS = KING_CLUBS-2;
    int my_hand[HAND_SIZE];
    int hand_value;

    // two card hand
    my_hand[0] = KING_DIAMONDS;
    my_hand[1] = TWO_OF_SPADES;
    my_hand[2] = 0;
    hand_value = get_hand_value(my_hand);
    TEST_CHECK(hand_value == 12);

    // two card hand with Ace
    my_hand[0] = ACE_HEARTS;
    my_hand[1] = TWO_OF_SPADES;
    my_hand[2] = 0;
    hand_value = get_hand_value(my_hand);
    TEST_CHECK(hand_value == 13);

    // three card hand with Ace
    my_hand[0] = ACE_HEARTS;
    my_hand[1] = TWO_OF_SPADES;
    my_hand[2] = SIX_OF_HEARTS;
    hand_value = get_hand_value(my_hand);
    TEST_CHECK(hand_value == 19);

    // three card hand with Ace as 1 
    my_hand[0] = ACE_HEARTS;
    my_hand[1] = JACK_OF_CLUBS;
    my_hand[2] = KING_CLUBS;
    hand_value = get_hand_value(my_hand);
    TEST_CHECK(hand_value == 21);

    // three cards over 21 is busted.
    my_hand[0] = TWO_OF_SPADES;
    my_hand[1] = JACK_OF_CLUBS;
    my_hand[2] = KING_CLUBS;
    hand_value = get_hand_value(my_hand);
    TEST_CHECK(hand_value == BUSTED);
    
    // Two Aces? Only one is adjusted to from 11 to 1
    my_hand[0] = ACE_HEARTS;
    my_hand[1] = TWO_OF_SPADES;
    my_hand[2] = ACE_SPADES;
    hand_value = get_hand_value(my_hand);
    TEST_CHECK(hand_value == 14);
}

void can_check_hand_for_ace()
{
    int my_hand[HAND_SIZE];
        
    my_hand[0] = KING_DIAMONDS;
    my_hand[1] = KING_HEARTS;
    my_hand[2] = 0;
    TEST_CHECK(!hand_has_ace(my_hand));
    my_hand[2] = ACE_SPADES;
    TEST_CHECK(hand_has_ace(my_hand));
}

// List of tests - key, value pairs with {NULL, NULL} termination.
TEST_LIST = {
    {"can make deck", can_make_deck},
    {"can check new deck is not shuffled", can_check_new_deck_is_not_shuffled},
    {"can check deck is shuffled", can_check_deck_is_shuffled},
    {"can deal card", can_deal_card},
    {"can show card", can_show_card},
    {"can fan new deck", can_fan_new_deck},
    {"can fan shuffled deck", can_fan_shuffled_deck},
    {"can get card rank", can_get_card_rank},
    {"can get card suit", can_get_card_suit},
    {"can get card face value", can_get_card_face_value},
    {"can get hand value", can_get_hand_value},
    {"can check hand for ace", can_check_hand_for_ace},

    { NULL, NULL }
};

#endif
